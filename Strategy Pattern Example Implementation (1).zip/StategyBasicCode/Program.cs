﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StategyExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Runner First = new Runner(new Robo());
            Runner Second = new Runner(new Tracks());
            Runner Third = new Runner(new Hover());
            Runner Fourth = new TrackedRunner();

            First.Run();
            Second.Run();
            Third.Run();
            Fourth.Run();

            Console.ReadLine();
        }
    }
}
