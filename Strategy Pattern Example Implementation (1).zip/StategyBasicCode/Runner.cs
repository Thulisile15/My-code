﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StategyExample
{
    class Runner
    {
        public Legs RunnerLegs;
        public Runner(Legs RunnerLegs)
        {
            this.RunnerLegs = RunnerLegs;
        }
        public void Run()
        {
            Console.WriteLine(RunnerLegs.Run());
        }
    }

}
