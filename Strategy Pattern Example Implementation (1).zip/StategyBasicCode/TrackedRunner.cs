﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StategyExample
{
    class TrackedRunner:Runner
    {
        public TrackedRunner() : base(new Tracks())
        { }
    }
}
