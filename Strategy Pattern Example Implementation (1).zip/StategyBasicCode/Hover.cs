﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StategyExample
{
    class Hover: Legs
    {
        public override String Run()
        {
            return "Hovering on a flame booster.";
        }
    }
}
