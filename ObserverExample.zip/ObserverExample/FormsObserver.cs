﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ObserverExample
{
    class FormsObserver :PictureBox, IObserver
    {
        ISubject TheSubject;
        Random rGenerator = new Random();

        public FormsObserver(ISubject TheSubject,int ScreenHeight, int ScreenWidth)
        {
            this.TheSubject = TheSubject;
            this.TheSubject.Attach(this);
            this.Height = 50;
            this.Width = 50;
            this.Top = rGenerator.Next(0, ScreenHeight - this.Height);
            this.Left = rGenerator.Next(0, ScreenWidth - this.Width);
            this.SizeMode = PictureBoxSizeMode.Zoom;
            this.Click += FormsObserver_Click;
        }

        private void FormsObserver_Click(object sender, EventArgs e)
        {
            TheSubject.Detach(this);
            this.Dispose();
        }

        public void Update(int Humidity)
        {
            if (Humidity < 33)
            {
                this.Image = Properties.Resources.Sunny;
            }
            else
            {
                if (Humidity < 67)
                {
                    this.Image = Properties.Resources.Cloudy;
                }
                else
                    this.Image = Properties.Resources.Rainy;
            }
        }
    }
}
