﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ObserverExample
{
    public partial class Form1 : Form
    {
        ISubject theSubject = new WeatherStation();
        public Form1()
        {
            InitializeComponent();
        }

        private void tmHumidity_Tick(object sender, EventArgs e)
        {
            ((WeatherStation)theSubject).SetHumidity();
            //Console.WriteLine(theSubject.GetHumidity());
        }

        private void btnAddConsoleObserver_Click(object sender, EventArgs e)
        {
            new ConsoleObserver(theSubject);
        }

        private void btnRemoveConsoleObserver_Click(object sender, EventArgs e)
        {
            theSubject.DetachLastOfType(typeof(ConsoleObserver));
        }

        private void btnAddFormsObserver_Click(object sender, EventArgs e)
        {
            this.Controls.Add(new FormsObserver(theSubject,this.Height,this.Width));
        }
    }
}
