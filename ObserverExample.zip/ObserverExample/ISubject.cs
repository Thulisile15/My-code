﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverExample
{
    interface ISubject
    {
        void Attach(IObserver Target);
        void Detach(IObserver Target);

        void Notify();

        void DetachLastOfType(Type TheType);
    }
}
