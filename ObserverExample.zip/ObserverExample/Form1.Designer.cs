﻿namespace ObserverExample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tmHumidity = new System.Windows.Forms.Timer(this.components);
            this.btnAddConsoleObserver = new System.Windows.Forms.Button();
            this.btnRemoveConsoleObserver = new System.Windows.Forms.Button();
            this.btnAddFormsObserver = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tmHumidity
            // 
            this.tmHumidity.Enabled = true;
            this.tmHumidity.Interval = 1000;
            this.tmHumidity.Tick += new System.EventHandler(this.tmHumidity_Tick);
            // 
            // btnAddConsoleObserver
            // 
            this.btnAddConsoleObserver.Location = new System.Drawing.Point(12, 12);
            this.btnAddConsoleObserver.Name = "btnAddConsoleObserver";
            this.btnAddConsoleObserver.Size = new System.Drawing.Size(129, 23);
            this.btnAddConsoleObserver.TabIndex = 0;
            this.btnAddConsoleObserver.Text = "Add Console Observer";
            this.btnAddConsoleObserver.UseVisualStyleBackColor = true;
            this.btnAddConsoleObserver.Click += new System.EventHandler(this.btnAddConsoleObserver_Click);
            // 
            // btnRemoveConsoleObserver
            // 
            this.btnRemoveConsoleObserver.Location = new System.Drawing.Point(147, 12);
            this.btnRemoveConsoleObserver.Name = "btnRemoveConsoleObserver";
            this.btnRemoveConsoleObserver.Size = new System.Drawing.Size(196, 23);
            this.btnRemoveConsoleObserver.TabIndex = 1;
            this.btnRemoveConsoleObserver.Text = "Remove Console Observer";
            this.btnRemoveConsoleObserver.UseVisualStyleBackColor = true;
            this.btnRemoveConsoleObserver.Click += new System.EventHandler(this.btnRemoveConsoleObserver_Click);
            // 
            // btnAddFormsObserver
            // 
            this.btnAddFormsObserver.Location = new System.Drawing.Point(12, 41);
            this.btnAddFormsObserver.Name = "btnAddFormsObserver";
            this.btnAddFormsObserver.Size = new System.Drawing.Size(331, 23);
            this.btnAddFormsObserver.TabIndex = 2;
            this.btnAddFormsObserver.Text = "Add Forms Observer";
            this.btnAddFormsObserver.UseVisualStyleBackColor = true;
            this.btnAddFormsObserver.Click += new System.EventHandler(this.btnAddFormsObserver_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(999, 484);
            this.Controls.Add(this.btnAddFormsObserver);
            this.Controls.Add(this.btnRemoveConsoleObserver);
            this.Controls.Add(this.btnAddConsoleObserver);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer tmHumidity;
        private System.Windows.Forms.Button btnAddConsoleObserver;
        private System.Windows.Forms.Button btnRemoveConsoleObserver;
        private System.Windows.Forms.Button btnAddFormsObserver;
    }
}

