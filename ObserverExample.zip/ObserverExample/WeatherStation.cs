﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverExample
{
    class WeatherStation:ISubject
    {
        int Humidity;
        Random rGenerator = new Random();
        List<IObserver> Observers = new List<IObserver>();

        public void SetHumidity()
        {
            this.Humidity = rGenerator.Next(0, 101);
            Notify();
        }

        public int GetHumidity()
        {
            return Humidity;
        }

        public void Attach(IObserver Target)
        {
            this.Observers.Add(Target);
        }

        public void Detach(IObserver Target)
        {
            this.Observers.Remove(Target);
        }

        public void Notify()
        {
            foreach (IObserver Current in Observers)
                Current.Update(Humidity);
        }

        public void DetachLastOfType(Type TheType)
        {
            IObserver TheObserver = null;

            foreach(IObserver Current in Observers)
            {
                if (Current.GetType() == TheType)
                {
                    TheObserver = Current;
                }
            }

            if (TheObserver != null)
                Observers.Remove(TheObserver);
        }
    }
}
