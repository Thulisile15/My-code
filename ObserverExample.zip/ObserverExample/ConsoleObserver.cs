﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverExample
{
    class ConsoleObserver : IObserver
    {
        ISubject TheSubject;

        public ConsoleObserver(ISubject TheSubject)
        {
            this.TheSubject = TheSubject;
            this.TheSubject.Attach(this);
        }
        public void Update(int Humidity)
        {
            Console.WriteLine(Humidity);
        }
    }
}
